class Editora {
    // properties
    _make: string= Editora
    _doors: number= 9
}