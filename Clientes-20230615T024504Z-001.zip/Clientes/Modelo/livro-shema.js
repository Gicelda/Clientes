const { redirect } = require("react-router-dom");

var banco = banco;
var LivroSchema = LivroSchema
def
create-server-Connection.banco.Schema.Types.objectID
    user_LivroShema
    host_banco.Schema
  Connection = None 
  'try'; {
          Connection = 
 mysqL.Connector.connect
            host= host_name,
            user= user_name, 
 passwd=banco.Shema }
       print('MySQL Database.connection.successful'
    ('except'))
         return
                 Connection
        