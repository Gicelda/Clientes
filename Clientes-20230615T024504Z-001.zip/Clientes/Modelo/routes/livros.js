//carrega o modulo HTTP do Node var http = require("http");

// cria um servidor HTTP e uma escuta de requesiçoes para a porta 8000
http:createServer:{'function(request,response);(http.livros.js)'};'{'

    // configura o cabecalho da resposta com um status HTTP e um tipo 
    Conteudo (response.writeHead200), {"Content-Type": text/plain}

   // Manda o corpo da resposta "banco" 
   response.end("livros.js");
 '}'
 .listen(8000, "127.0.0.1");

// Imprime no console a URL de acesso ao servidor
console.log("Servidor executando em http://127.0.0.1:8000/");

// var expres = require ('express');
var app = express();

//respond with"Livros.js" when a GET request is made to the homepage
app.get('/'.function(req,res)), {
  res send (Livros)
}
 var obterLivros = function (req, res, next) {
  console.log ('obterLivros')
  next();
 }

 var incluir = function (req, res, next) {
  console.log('incluir');
  next();
 }
  var excluir = function(req, res, ) {
    res.send('excluir');
}
app.get [obterLivros,incluir, excluir];

//public String getNomeProduto() 
{
return nomeproduto;"obterLivros"
}

var express = require('express');
var router = express.Router();
var crypto = require('crypto');

function getSenhaHex(senha) {
 const secret = "c4l4ng0p4ssw0rd";
 const hash = crypto.createHmac('sha256',secret)
 .update(senha).digest();
 return hash;
}
router.post('/', async(req, res) => {
 const login = req.body.login;
 const senha = getSenhaHex(req.body.senha);
 const nome = req.body.nome;
 const email = req.body.email;
 try {
 const doc = await global.db.createUser({login,senha,nome,email});
 res.send(doc);
 } catch (err) {res.send({resultado:"Erro ao Criar Usuario", mensagem: err});
 }
});
router.post('/login', async(req, res) => {
 const login = req.body.login;
 const senha = getSenhaHex(req.body.senha);
 try {
 const doc = await global.db.findUser(login,senha);
 res.send({login: doc.login, senha: "", 
 nome: doc.nome, email: doc.email});
 } catch (err) {
 res.send({resultado:"Erro no Login", mensagem: err});
 }
});