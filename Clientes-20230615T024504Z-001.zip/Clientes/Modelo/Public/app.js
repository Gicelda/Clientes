var express =require('express')
const { useLocation } = require('react-router-dom')
const { useRouteId } = require('react-router/dist/lib/hooks')
var app = express()
var livroRouter = routes/livros
app = routes/livros
app routes/"/livros"
var cors = require('cors')
var app = use();
app.use (cors());"/livros"