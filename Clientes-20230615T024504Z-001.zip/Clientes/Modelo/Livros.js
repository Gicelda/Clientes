import class livros
//*
    id:String
    name:String
    description:String
    endpoint:String
