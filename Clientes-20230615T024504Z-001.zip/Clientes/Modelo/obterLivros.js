let livros = () => {
  return 'metodo find';
};
    console.log(find)
async function obterLivros(url) { 
  let v;
  try {
    v = await baixarLivros(url);
  } catch(e) {
    v = await baixarLivrosReservas(url);
  }
  return processarLivrosfind(v);
}

//GET method router
app.get('/', function (req, res)  {
  res.send('GET request book submission');
});