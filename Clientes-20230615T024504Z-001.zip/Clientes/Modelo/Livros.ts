class Livro {
        // properties
    _make: string= Livro
    _titulo : Livro _titulo
    _resumo : Livro _resumo
    _autores: Livro _autores
    _doors: Livro 9
}
    // construtor
    this._doors = 9
