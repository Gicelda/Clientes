var app = express();
routes/livros
const cors = require('cors');
app.use(cors({livroRouter}
 origin: 'http://localhost:4200'
function: createUser(usuario) {
return global.conn.collection("usuarios")
 .insertOne(usuario); 
}
function findUser(login,senha){
 return global.conn.collection("usuarios")
 .findOne({login, senha});
}

module.export= '{('findAll, insert, deleteOne, findOne, 
 createUser, findUser')}'

 var cors =require ('cors')
 var app = express ();
 app.use (cors());