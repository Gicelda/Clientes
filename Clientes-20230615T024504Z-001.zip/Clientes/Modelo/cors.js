const { normalizePort } = require(processo.env.PORT||'3000')
var port = normalizePort(process.env.PORT||'3030')
cors-OriginResourceSharing
var port = normalizePort

var cors = require ('cors')
var app = express();
app.use (cors());